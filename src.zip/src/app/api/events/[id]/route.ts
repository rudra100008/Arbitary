import { NextRequest, NextResponse } from "next/server";
import { requireAdmin } from "@/src/services/auth.service";
import { EventService } from "@/src/services/event.service";
import { AdminLogService, extractIpFromRequest } from "@/src/services/admin-log.service";
import { toNextResponse } from "@/src/lib/api-response";

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const param = await params;
  const id = Number(param.id);
  if (isNaN(id)) {
    return NextResponse.json({ error: "Invalid event ID" }, { status: 400 });
  }

  const result = await EventService.getEventById(id);
  if (!result.success) return toNextResponse(result);

  return NextResponse.json({ success: true, event: result.data });
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin();
  if (!auth.success) {
    return NextResponse.json({ error: auth.error }, { status: 401 });
  }

  const param = await params;
  const id = Number(param.id);
  if (isNaN(id)) {
    return NextResponse.json({ error: "Invalid event ID" }, { status: 400 });
  }

  const body = await req.json();
  const result = await EventService.createOrUpdateEvent({ ...body, id });
  if (!result.success) return toNextResponse(result);

  return NextResponse.json({ success: true, event: result.data });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin();
  if (!auth.success) {
    return NextResponse.json({ error: auth.error }, { status: 401 });
  }

  const param = await params;
  const id = Number(param.id);
  if (isNaN(id)) {
    return NextResponse.json({ error: "Invalid event ID" }, { status: 400 });
  }

  const result = await EventService.deleteEvent(id);
  if (!result.success) return toNextResponse(result);

  await AdminLogService.logAction({
    adminId: auth.data.id,
    action: "delete_event",
    description: `Event #${id} deleted`,
    entityType: "event",
    entityId: id,
    ipAddress: extractIpFromRequest(req),
  });

  return NextResponse.json({ success: true, message: "Event deleted" });
}
